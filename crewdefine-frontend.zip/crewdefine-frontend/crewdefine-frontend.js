const BUILTIN_TOOLS = [
  ["web_search", "Search the web", "Find useful pages and background information."],
  ["news_search", "Check recent news", "Look for fresh updates and current events."],
  ["calculator", "Run calculations", "Work through numbers, estimates, and comparisons."],
  ["document", "Read uploaded files", "Search inside documents your organization provides."],
  ["knowledge_base", "Use internal knowledge", "Look up relevant information already in LabZ."],
  ["swot", "Compare strengths and risks", "Organize pros, cons, opportunities, and threats."],
  ["visualizer", "Create charts", "Turn numbers or categories into visual summaries."],
  ["extract_citations", "Add source notes", "Keep track of where important facts came from."],
  ["extract_citations_structured", "Organize sources", "Prepare sources in a structured format."],
  ["generate_recommendations", "Suggest resources", "Recommend helpful readings or next steps."],
  ["image_generator", "Create images", "Generate visuals for ideas or presentation material."],
  ["validate_information_sufficiency", "Check what is missing", "Notice gaps before answering."],
  ["generate_followup_questions", "Ask better questions", "Suggest clarifying questions when the goal is fuzzy."],
  ["scrape_website", "Read a website", "Pull information from a specific web page."],
];

const STORAGE_KEY = "crewdefine-studio-draft";

const sampleCrew = {
  name: "bakery-launch-crew",
  description:
    "Launch a neighborhood bakery with local competitor research, pricing ideas, sponsor outreach, and a simple opening-week plan.",
  agents: [
    {
      id: "team_lead",
      name: "Team Lead",
      role: "Keeps the launch plan focused and turns everyone’s work into clear next steps.",
      tools: ["knowledge_base", "generate_followup_questions"],
      can_delegate_to: ["local_researcher", "numbers_helper", "outreach_writer"],
      system_prompt:
        "You are the team lead for a bakery launch crew. Clarify the launch goal, decide what research is needed, ask the right helpers for input, and turn the work into a practical opening plan. Keep the final answer simple, specific, and easy for a small business owner to act on.",
      model: "",
      data_extraction_note: "",
    },
    {
      id: "local_researcher",
      name: "Local Researcher",
      role: "Finds nearby competitors, customer signals, and useful local context.",
      tools: ["web_search", "news_search", "scrape_website", "extract_citations"],
      can_delegate_to: [],
      system_prompt:
        "You are the local researcher for a bakery launch crew. Find nearby competitors, pricing signals, customer needs, local events, and neighborhood context. Prefer concrete facts over broad guesses, keep sources attached to important claims, and summarize what matters most.",
      model: "",
      data_extraction_note: "Return finding, source, confidence, and why it matters.",
    },
    {
      id: "numbers_helper",
      name: "Numbers Helper",
      role: "Compares rough costs, pricing options, and simple launch tradeoffs.",
      tools: ["calculator", "visualizer"],
      can_delegate_to: [],
      system_prompt:
        "You are the numbers helper for a bakery launch crew. Turn pricing and launch options into simple assumptions, compare rough costs and upside, and explain the tradeoffs without jargon. Keep the math readable and useful for a small business owner.",
      model: "",
      data_extraction_note: "Return assumptions, rough range, and recommendation.",
    },
    {
      id: "outreach_writer",
      name: "Outreach Writer",
      role: "Drafts sponsor messages, launch copy, and customer-facing materials.",
      tools: ["generate_recommendations", "extract_citations_structured"],
      can_delegate_to: [],
      system_prompt:
        "You are the outreach writer for a bakery launch crew. Turn the research and plan into warm, clear messages for sponsors, partners, and first customers. Keep the writing natural, specific, and easy to personalize.",
      model: "",
      data_extraction_note: "Return audience, message, and call to action.",
    },
  ],
  customTools: [],
};

let state = loadDraft();
let selectedId = state.agents[0]?.id || "";
let shouldClearGoalOnFocus = true;

const els = {
  crewName: document.querySelector("#crewName"),
  crewDescription: document.querySelector("#crewDescription"),
  validationStatus: document.querySelector("#validationStatus"),
  agentList: document.querySelector("#agentList"),
  addAgent: document.querySelector("#addAgent"),
  removeAgent: document.querySelector("#removeAgent"),
  agentId: document.querySelector("#agentId"),
  agentName: document.querySelector("#agentName"),
  agentRole: document.querySelector("#agentRole"),
  toolGrid: document.querySelector("#toolGrid"),
  toolCount: document.querySelector("#toolCount"),
  customTools: document.querySelector("#customTools"),
  dataNote: document.querySelector("#dataNote"),
  agentModel: document.querySelector("#agentModel"),
  systemPrompt: document.querySelector("#systemPrompt"),
  delegationList: document.querySelector("#delegationList"),
  yamlPreview: document.querySelector("#yamlPreview"),
  previewLabel: document.querySelector("#previewLabel"),
  agentMetric: document.querySelector("#agentMetric"),
  toolMetric: document.querySelector("#toolMetric"),
  edgeMetric: document.querySelector("#edgeMetric"),
  graph: document.querySelector("#graph"),
  missionTitle: document.querySelector("#missionTitle"),
  missionSummary: document.querySelector("#missionSummary"),
  selectedMemberTitle: document.querySelector("#selectedMemberTitle"),
  copyYaml: document.querySelector("#copyYaml"),
  downloadYaml: document.querySelector("#downloadYaml"),
  downloadReadme: document.querySelector("#downloadReadme"),
  downloadJson: document.querySelector("#downloadJson"),
  draftFromPurpose: document.querySelector("#draftFromPurpose"),
  loadSample: document.querySelector("#loadSample"),
  resetDraft: document.querySelector("#resetDraft"),
  toast: document.querySelector("#toast"),
  teamSection: document.querySelector(".team-section"),
};

function blankCrew() {
  return {
    name: "new-crew",
    description: "",
    agents: [
      {
        id: "director",
        name: "Team Lead",
        role: "Keeps the work focused and turns everyone’s input into the final answer.",
        tools: ["knowledge_base"],
        can_delegate_to: [],
        system_prompt:
          "You are the director for this LabZ crew. Clarify the user's goal, decide which evidence is needed, delegate work when another specialist is better suited, and synthesize the final answer. Be concise, explicit about uncertainty, and include practical next steps.",
        model: "",
        data_extraction_note: "",
      },
    ],
    customTools: [],
  };
}

function loadDraft() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? normalizeCrew(JSON.parse(raw)) : blankCrew();
  } catch {
    return blankCrew();
  }
}

function normalizeCrew(crew) {
  const normalized = { ...blankCrew(), ...crew };
  normalized.agents = Array.isArray(crew.agents) && crew.agents.length ? crew.agents : blankCrew().agents;
  normalized.customTools = Array.isArray(crew.customTools) ? crew.customTools : [];
  return normalized;
}

function saveDraft() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state, null, 2));
}

function slugify(value, separator = "-", fallback = "new-crew") {
  return (
    value
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, separator)
      .replace(new RegExp(`${separator}+`, "g"), separator)
      .replace(new RegExp(`^${separator}|${separator}$`, "g"), "") || fallback
  );
}

function snakeify(value) {
  if (!value.trim()) return "";
  const snake = slugify(value, "_", "");
  return /^[a-z]/.test(snake) ? snake : `agent_${snake}`;
}

function selectedAgent() {
  return state.agents.find((agent) => agent.id === selectedId) || state.agents[0];
}

function setSelected(id) {
  selectedId = id;
  render();
}

function render() {
  if (!state.agents.length) {
    state.agents.push(blankCrew().agents[0]);
    selectedId = state.agents[0].id;
  }
  if (!selectedAgent()) selectedId = state.agents[0].id;
  const agent = selectedAgent();

  els.crewName.value = state.name;
  els.crewDescription.value = state.description;
  els.agentId.value = agent.id;
  els.agentName.value = agent.name;
  els.agentRole.value = agent.role;
  els.customTools.value = customToolsFor(agent).join(", ");
  els.dataNote.value = agent.data_extraction_note || "";
  els.agentModel.value = agent.model || "";
  els.systemPrompt.value = agent.system_prompt;
  els.selectedMemberTitle.textContent = agent.name || "Team member";

  renderAgents();
  renderTools(agent);
  renderDelegation(agent);
  renderMetrics();
  renderGraph();
  renderMission();
  renderPreview(agent);
  renderValidation();
}

function renderMission() {
  els.missionTitle.textContent = state.name
    .split("-")
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(" ");
  els.missionSummary.textContent = state.description || "Waiting for a goal.";
}

function renderAgents() {
  els.agentList.innerHTML = "";
  state.agents.forEach((agent) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = `agent-card${agent.id === selectedId ? " active" : ""}`;
    const count = agent.tools.length;
    button.innerHTML = `
      <div>
        <strong>${escapeHtml(agent.name || agent.id)}</strong>
        <span>${escapeHtml(agent.role || "No responsibility yet")}</span>
      </div>
      <small>${count} ${count === 1 ? "ability" : "abilities"}</small>
    `;
    button.addEventListener("click", () => setSelected(agent.id));
    els.agentList.append(button);
  });
}

function renderTools(agent) {
  els.toolGrid.innerHTML = "";
  const builtin = new Set(BUILTIN_TOOLS.map(([id]) => id));
  const selected = new Set(agent.tools.filter((tool) => builtin.has(tool)));
  BUILTIN_TOOLS.forEach(([id, labelText, summary]) => {
    const label = document.createElement("label");
    label.className = "tool-chip";
    label.innerHTML = `
      <input type="checkbox" ${selected.has(id) ? "checked" : ""} data-tool="${id}" />
      <span><strong>${labelText}</strong><span>${summary}</span><small>${id}</small></span>
    `;
    label.querySelector("input").addEventListener("change", (event) => {
      toggleTool(agent, id, event.target.checked);
    });
    els.toolGrid.append(label);
  });
  els.toolCount.textContent = `${agent.tools.length} chosen`;
}

function renderDelegation(agent) {
  els.delegationList.innerHTML = "";
  const peers = state.agents.filter((candidate) => candidate.id !== agent.id);
  if (!peers.length) {
    els.delegationList.innerHTML = '<p class="muted">Add another team member to create handoffs.</p>';
    return;
  }

  peers.forEach((peer) => {
    const label = document.createElement("label");
    label.className = "delegate-row";
    label.innerHTML = `
      <input type="checkbox" ${agent.can_delegate_to.includes(peer.id) ? "checked" : ""} data-agent="${peer.id}" />
      <span><strong>${escapeHtml(peer.name)}</strong><span>${peer.id}</span></span>
    `;
    label.querySelector("input").addEventListener("change", (event) => {
      if (event.target.checked) {
        agent.can_delegate_to = unique([...agent.can_delegate_to, peer.id]);
      } else {
        agent.can_delegate_to = agent.can_delegate_to.filter((id) => id !== peer.id);
      }
      commit();
    });
    els.delegationList.append(label);
  });
}

function renderMetrics() {
  const uniqueTools = unique(state.agents.flatMap((agent) => agent.tools));
  const edges = state.agents.reduce((total, agent) => total + agent.can_delegate_to.length, 0);
  els.agentMetric.textContent = state.agents.length;
  els.toolMetric.textContent = uniqueTools.length;
  els.edgeMetric.textContent = edges;
}

function renderGraph() {
  const lines = state.agents.flatMap((agent) =>
    agent.can_delegate_to.map((target) => ({ source: agent.id, target })),
  );
  els.graph.innerHTML = "";
  if (!lines.length) {
    els.graph.innerHTML = '<p class="muted">No delegation edges yet.</p>';
    return;
  }
  lines.forEach((line) => {
    const row = document.createElement("div");
    row.className = "graph-line";
    row.innerHTML = `<span class="node">${friendlyName(line.source)}</span><span class="arrow">asks</span><span class="node">${friendlyName(line.target)}</span>`;
    els.graph.append(row);
  });
}

function friendlyName(id) {
  return state.agents.find((agent) => agent.id === id)?.name || id;
}

function renderPreview(agent) {
  els.previewLabel.textContent = `${agent.id}.yaml`;
  els.yamlPreview.textContent = agentToYaml(agent);
}

function renderValidation() {
  const errors = validateCrew();
  els.validationStatus.textContent = errors.length ? `${errors.length} fix${errors.length === 1 ? "" : "es"}` : "Ready";
  els.validationStatus.classList.toggle("ok", !errors.length);
  els.validationStatus.title = errors.join("\n");
}

const SPECIALIST_TEMPLATES = [
  {
    id: "meal_planner",
    name: "Meal Planner",
    role: "Builds a realistic menu around preferences, schedule, and variety.",
    tools: ["generate_followup_questions", "knowledge_base"],
    keywords: ["meal", "meals", "meal prep", "food", "recipe", "recipes", "dinner", "lunch", "breakfast", "cook", "cooking", "nutrition", "diet"],
    focus: "Turn the goal into a practical meal plan with enough variety, realistic prep, and clear choices.",
    note: "Return meal, reason, prep need, and substitution options.",
  },
  {
    id: "grocery_planner",
    name: "Grocery Planner",
    role: "Turns meals into a clear shopping list and ingredient plan.",
    tools: ["calculator", "generate_recommendations"],
    keywords: ["grocery", "groceries", "shopping", "ingredients", "pantry", "store", "budget", "cost"],
    focus: "Organize ingredients, quantities, shopping categories, and budget-conscious swaps.",
    note: "Return item, quantity, category, and optional substitute.",
  },
  {
    id: "prep_scheduler",
    name: "Prep Scheduler",
    role: "Maps cooking, batching, storage, and reheating into a simple routine.",
    tools: ["generate_followup_questions", "knowledge_base"],
    keywords: ["meal prep", "batch", "batch cooking", "prep", "weekly meals", "leftovers", "freezer", "storage", "routine"],
    focus: "Create an efficient prep schedule with batching, storage, and reheating steps.",
    note: "Return task, timing, storage note, and day to use.",
  },
  {
    id: "event_planner",
    name: "Event Planner",
    role: "Builds the timeline, logistics, and day-of plan.",
    tools: ["generate_followup_questions", "knowledge_base"],
    keywords: ["event", "fundraiser", "conference", "workshop", "opening", "launch party", "venue", "attendees"],
    focus: "Turn the goal into a realistic sequence of milestones, logistics, owners, and day-of details.",
    note: "Return timeline, owners, dependencies, and next decisions.",
  },
  {
    id: "sponsor_scout",
    name: "Sponsor Scout",
    role: "Finds partner, sponsor, and outreach opportunities.",
    tools: ["web_search", "scrape_website", "extract_citations"],
    keywords: ["sponsor", "partner", "donor", "fundraiser", "community", "local business", "outreach"],
    focus: "Identify promising partners, why they fit, and what kind of ask would be natural.",
    note: "Return target, reason to contact, offer, and first message angle.",
  },
  {
    id: "market_researcher",
    name: "Market Researcher",
    role: "Finds market, competitor, audience, and trend signals.",
    tools: ["web_search", "news_search", "scrape_website", "extract_citations"],
    keywords: ["market", "competitor", "competitive", "customer", "audience", "industry", "pricing", "trend", "research"],
    focus: "Find useful outside signals, summarize what matters, and keep sources attached to important claims.",
    note: "Return finding, source, confidence, and why it matters.",
  },
  {
    id: "numbers_analyst",
    name: "Numbers Analyst",
    role: "Works through budgets, pricing, forecasts, and tradeoffs.",
    tools: ["calculator", "visualizer"],
    keywords: ["budget", "price", "pricing", "forecast", "revenue", "cost", "margin", "finance", "funding", "compare"],
    focus: "Turn the goal into simple assumptions, rough ranges, and clear financial tradeoffs.",
    note: "Return assumptions, rough range, calculation, and recommendation.",
  },
  {
    id: "outreach_writer",
    name: "Outreach Writer",
    role: "Drafts messages, asks, announcements, and follow-up copy.",
    tools: ["generate_recommendations", "extract_citations_structured"],
    keywords: ["email", "message", "outreach", "sponsor", "donor", "announce", "launch", "copy", "social", "newsletter"],
    focus: "Create clear, warm, audience-aware copy that is easy to personalize and act on.",
    note: "Return audience, message, tone, and call to action.",
  },
  {
    id: "content_strategist",
    name: "Content Strategist",
    role: "Shapes topics, positioning, and publishing plans.",
    tools: ["generate_recommendations", "knowledge_base"],
    keywords: ["content", "blog", "newsletter", "calendar", "campaign", "brand", "positioning", "story", "marketing"],
    focus: "Turn the goal into a coherent message, content structure, and practical publishing plan.",
    note: "Return audience, angle, content pieces, and publishing order.",
  },
  {
    id: "learning_designer",
    name: "Learning Designer",
    role: "Designs lessons, exercises, and learning flow.",
    tools: ["document", "knowledge_base", "generate_followup_questions"],
    keywords: ["training", "course", "lesson", "learn", "onboarding", "workshop", "curriculum", "teach", "enablement"],
    focus: "Break the goal into teachable modules, exercises, checkpoints, and rollout steps.",
    note: "Return modules, exercise, objective, and success check.",
  },
  {
    id: "product_strategist",
    name: "Product Strategist",
    role: "Frames product options, users, value, and launch angle.",
    tools: ["knowledge_base", "validate_information_sufficiency"],
    keywords: ["product", "feature", "app", "software", "prototype", "roadmap", "launch", "user", "ux"],
    focus: "Clarify the user, value proposition, product options, and what should be tested first.",
    note: "Return user, problem, option, risk, and next test.",
  },
  {
    id: "task_planner",
    name: "Task Planner",
    role: "Breaks the goal into clear steps and a simple order of operations.",
    tools: ["generate_followup_questions", "knowledge_base"],
    keywords: ["organize", "prepare", "get ready", "personal", "home", "life", "routine", "project"],
    focus: "Turn the goal into a practical sequence of steps, decisions, and checkpoints.",
    note: "Return step, order, decision needed, and completion signal.",
  },
  {
    id: "operations_planner",
    name: "Operations Planner",
    role: "Turns the goal into repeatable steps, owners, and process.",
    tools: ["knowledge_base", "generate_followup_questions"],
    keywords: ["process", "operations", "workflow", "runbook", "team", "handoff", "schedule", "rollout", "plan"],
    focus: "Define the operating plan, ownership, dependencies, and repeatable steps.",
    note: "Return phase, owner, dependency, and output.",
  },
  {
    id: "risk_reviewer",
    name: "Risk Reviewer",
    role: "Spots risks, gaps, constraints, and unanswered questions.",
    tools: ["validate_information_sufficiency", "generate_followup_questions"],
    keywords: ["risk", "legal", "policy", "compliance", "approval", "security", "privacy", "safety", "stakeholder"],
    focus: "Identify what could go wrong, what is missing, and which decisions need extra care.",
    note: "Return risk, likelihood, impact, mitigation, and owner.",
  },
  {
    id: "data_analyst",
    name: "Data Analyst",
    role: "Structures data, metrics, charts, and measurement plans.",
    tools: ["calculator", "visualizer", "validate_information_sufficiency"],
    keywords: ["data", "metrics", "dashboard", "chart", "measure", "kpi", "report", "analysis", "survey"],
    focus: "Turn the goal into useful metrics, data structure, and clear visual or analytical outputs.",
    note: "Return metric, source, calculation, and interpretation.",
  },
  {
    id: "document_synthesizer",
    name: "Document Synthesizer",
    role: "Reads provided material and turns it into usable direction.",
    tools: ["document", "knowledge_base", "extract_citations_structured"],
    keywords: ["document", "docs", "file", "policy", "manual", "notes", "transcript", "internal", "knowledge"],
    focus: "Extract what matters from supplied material and organize it into clear decisions or next steps.",
    note: "Return source, relevant detail, implication, and open question.",
  },
];

const DEFAULT_SPECIALIST_IDS = ["task_planner", "operations_planner", "risk_reviewer"];

function chooseSpecialists(goal) {
  const lowerGoal = goal.toLowerCase();
  const scored = SPECIALIST_TEMPLATES.map((template) => ({
    ...template,
    score: template.keywords.reduce((total, keyword) => {
      return total + (keywordMatches(lowerGoal, keyword) ? 1 : 0);
    }, 0),
  })).sort((a, b) => b.score - a.score || a.name.localeCompare(b.name));

  const selected = scored.filter((template) => template.score > 0).slice(0, 3);
  for (const id of DEFAULT_SPECIALIST_IDS) {
    if (selected.length >= 3) break;
    const fallback = SPECIALIST_TEMPLATES.find((template) => template.id === id);
    if (fallback && !selected.some((template) => template.id === fallback.id)) {
      selected.push({ ...fallback, score: 0 });
    }
  }
  return selected.slice(0, 3);
}

function keywordMatches(goal, keyword) {
  const escaped = keyword.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  return new RegExp(`(^|[^a-z0-9])${escaped}([^a-z0-9]|$)`, "i").test(goal);
}

function specialistToAgent(template, purpose) {
  return {
    id: template.id,
    name: template.name,
    role: template.role,
    tools: listForPurpose(template.tools, purpose),
    can_delegate_to: [],
    system_prompt: `You are the ${template.name.toLowerCase()} for a LabZ crew created for this purpose: ${purpose}

${template.focus} Keep the work specific to the user's goal, avoid generic advice, and return concise findings the team lead can use immediately.`,
    model: "",
    data_extraction_note: template.note,
  };
}

function listForPurpose(tools, purpose) {
  const lowerPurpose = purpose.toLowerCase();
  return unique([
    ...tools,
    lowerPurpose.includes("news") || lowerPurpose.includes("current") ? "news_search" : "",
    lowerPurpose.includes("chart") || lowerPurpose.includes("visual") ? "visualizer" : "",
  ]);
}

function buildCrewFromPurpose(purpose) {
  const cleanPurpose =
    purpose.trim() ||
    "Help a user define, research, analyze, and deliver a high-quality answer for a specific goal.";
  const baseName = slugify(cleanPurpose.split(/[,.]/)[0].slice(0, 46), "-", "purpose-crew");
  const crewName = baseName.endsWith("-crew") ? baseName : `${baseName}-crew`;
  const specialists = chooseSpecialists(cleanPurpose);
  const specialistAgents = specialists.map((template) => specialistToAgent(template, cleanPurpose));

  return {
    name: crewName,
    description: cleanPurpose,
    agents: [
      {
        id: "crew_director",
        name: "Team Lead",
        role: "Keeps the team focused and turns everyone’s input into the final answer.",
        tools: ["knowledge_base", "generate_followup_questions"],
        can_delegate_to: specialistAgents.map((agent) => agent.id),
        system_prompt: `You are the director for a LabZ crew created for this purpose: ${cleanPurpose}

Clarify the user's desired outcome, decide which specialist should handle each part, and synthesize the final response. Keep the crew aligned to the original purpose, call out uncertainty, and end with practical next steps.`,
        model: "",
        data_extraction_note: "",
      },
      ...specialistAgents,
    ],
    customTools: [],
  };
}

function validateCrew() {
  const errors = [];
  if (!/^[a-z][a-z0-9-]*$/.test(state.name)) errors.push("Crew name must be kebab-case.");
  const ids = state.agents.map((agent) => agent.id);
  state.agents.forEach((agent) => {
    if (!/^[a-z][a-z0-9_]*$/.test(agent.id)) errors.push(`${agent.id} must be snake_case.`);
    if (!agent.name.trim()) errors.push(`${agent.id} needs a name.`);
    if (!agent.role.trim()) errors.push(`${agent.id} needs a role.`);
    if ((agent.system_prompt || "").trim().length < 80) errors.push(`${agent.id} needs a longer system prompt.`);
    agent.can_delegate_to.forEach((target) => {
      if (!ids.includes(target)) errors.push(`${agent.id} delegates to unknown agent ${target}.`);
      if (target === agent.id) errors.push(`${agent.id} delegates to itself.`);
    });
  });
  ids.forEach((id) => {
    if (ids.indexOf(id) !== ids.lastIndexOf(id)) errors.push(`Duplicate agent id: ${id}.`);
  });
  return unique(errors);
}

function toggleTool(agent, tool, checked) {
  if (checked) {
    agent.tools = unique([...agent.tools, tool]);
  } else {
    agent.tools = agent.tools.filter((id) => id !== tool);
  }
  commit();
}

function customToolsFor(agent) {
  const builtin = new Set(BUILTIN_TOOLS.map(([id]) => id));
  return agent.tools.filter((tool) => !builtin.has(tool));
}

function commit() {
  saveDraft();
  render();
}

function updateSelected(field, value) {
  const agent = selectedAgent();
  if (!agent) return;
  agent[field] = value;
  if (field === "id") {
    const oldId = selectedId;
    selectedId = value;
    state.agents.forEach((candidate) => {
      candidate.can_delegate_to = candidate.can_delegate_to.map((id) => (id === oldId ? value : id));
    });
  }
  commit();
}

function agentToYaml(agent) {
  const lines = [
    `id: ${agent.id}`,
    `name: ${quoteYaml(agent.name)}`,
    `role: ${quoteYaml(agent.role)}`,
    "tools:",
    ...listLines(agent.tools),
    "can_delegate_to:",
    ...listLines(agent.can_delegate_to),
  ];
  if (agent.data_extraction_note) lines.push(`data_extraction_note: ${quoteYaml(agent.data_extraction_note)}`);
  if (agent.model) lines.push(`model: ${quoteYaml(agent.model)}`);
  lines.push("system_prompt: |");
  lines.push(...indentBlock(agent.system_prompt || ""));
  return `${lines.join("\n")}\n`;
}

function listLines(items) {
  return items.length ? items.map((item) => `  - ${item}`) : ["  []"];
}

function indentBlock(value) {
  const text = value.trimEnd() || "TODO: write a substantive prompt for this agent.";
  return text.split("\n").map((line) => `  ${line}`);
}

function quoteYaml(value) {
  if (/^[A-Za-z0-9_./ -]+$/.test(value) && value.trim() === value && value !== "") return value;
  return JSON.stringify(value);
}

function readmeText() {
  const agentRows = state.agents.map((agent) => `| \`${agent.id}\` | ${agent.name} | ${agent.role} |`).join("\n");
  const toolSet = unique(state.agents.flatMap((agent) => customToolsFor(agent)));
  const toolRows = toolSet.length
    ? toolSet.map((tool) => `| \`${tool}\` | Custom tool placeholder from Studio export. |`).join("\n")
    : "_None - this crew uses only built-in LabZ tools._";
  const delegation = state.agents
    .filter((agent) => agent.can_delegate_to.length)
    .map((agent) => `- \`${agent.id}\` -> ${agent.can_delegate_to.map((id) => `\`${id}\``).join(", ")}`)
    .join("\n");

  return `# ${state.name}

${state.description}

## Agents

| ID | Name | Role |
| --- | --- | --- |
${agentRows}

## Custom tools

| ID | Description |
| --- | --- |
${toolRows}

## Delegation graph

${delegation || "_No delegation configured._"}

## Installing into LabZ

1. Copy the generated agent YAML files into \`LabZ/backend/src/agents/config/\`.
2. Add custom tool stubs under \`LabZ/backend/src/agents/tools/\` and register each tool.
3. Run \`crewdefine validate <crew-dir>\` before using the crew.
`;
}

function download(filename, content, type = "text/plain") {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.append(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

function unique(items) {
  return [...new Set(items.filter(Boolean))];
}

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function toast(message) {
  els.toast.textContent = message;
  els.toast.classList.add("show");
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => els.toast.classList.remove("show"), 2200);
}

function assembleTeamFromGoal(goal, { jump = false } = {}) {
  const cleanGoal = goal.trim();
  state = buildCrewFromPurpose(cleanGoal);
  selectedId = state.agents[0].id;
  shouldClearGoalOnFocus = true;
  commit();
  toast("Team assembled.");
  if (jump) {
    els.teamSection.scrollIntoView({ block: "start", behavior: "smooth" });
  }
}

function clearGoalEntryOnce() {
  if (!shouldClearGoalOnFocus || !els.crewDescription.value.trim()) return;
  shouldClearGoalOnFocus = false;
  state.description = "";
  els.crewDescription.value = "";
  saveDraft();
  renderMission();
}

els.crewName.addEventListener("input", (event) => {
  state.name = slugify(event.target.value);
  commit();
});
els.crewDescription.addEventListener("input", (event) => {
  shouldClearGoalOnFocus = false;
  state.description = event.target.value;
  if (event.target.value.trim()) {
    state.name = slugify(event.target.value.split(/[,.]/)[0].slice(0, 46));
  }
  commit();
});
els.crewDescription.addEventListener("focus", clearGoalEntryOnce);
els.crewDescription.addEventListener("pointerdown", clearGoalEntryOnce);
els.crewDescription.addEventListener("click", clearGoalEntryOnce);
els.agentId.addEventListener("input", (event) => updateSelected("id", snakeify(event.target.value)));
els.agentName.addEventListener("input", (event) => updateSelected("name", event.target.value));
els.agentRole.addEventListener("input", (event) => updateSelected("role", event.target.value));
els.dataNote.addEventListener("input", (event) => updateSelected("data_extraction_note", event.target.value));
els.agentModel.addEventListener("input", (event) => updateSelected("model", event.target.value));
els.systemPrompt.addEventListener("input", (event) => updateSelected("system_prompt", event.target.value));
els.customTools.addEventListener("change", (event) => {
  const agent = selectedAgent();
  const builtin = new Set(BUILTIN_TOOLS.map(([id]) => id));
  const builtins = agent.tools.filter((tool) => builtin.has(tool));
  const custom = event.target.value
    .split(",")
    .map((tool) => snakeify(tool))
    .filter((tool) => tool !== "agent_");
  agent.tools = unique([...builtins, ...custom]);
  commit();
});

els.addAgent.addEventListener("click", () => {
  const next = state.agents.length + 1;
  const id = `specialist_${next}`;
  state.agents.push({
    id,
    name: `Specialist ${next}`,
    role: "Owns a focused part of the crew workflow.",
    tools: [],
    can_delegate_to: [],
    system_prompt:
      "You are a focused specialist in this LabZ crew. Understand the task handed to you, use only the tools that improve the answer, explain key assumptions, and return concise findings that another agent can act on.",
    model: "",
    data_extraction_note: "",
  });
  selectedId = id;
  commit();
});

els.removeAgent.addEventListener("click", () => {
  if (state.agents.length === 1) {
    toast("A crew needs at least one agent.");
    return;
  }
  const removed = selectedId;
  state.agents = state.agents.filter((agent) => agent.id !== removed);
  state.agents.forEach((agent) => {
    agent.can_delegate_to = agent.can_delegate_to.filter((id) => id !== removed);
  });
  selectedId = state.agents[0].id;
  commit();
});

els.copyYaml.addEventListener("click", async () => {
  await navigator.clipboard.writeText(agentToYaml(selectedAgent()));
  toast("Setup copied for the selected team member.");
});

els.downloadYaml.addEventListener("click", () => {
  const agent = selectedAgent();
  download(`${agent.id}.yaml`, agentToYaml(agent), "text/yaml");
});

els.downloadReadme.addEventListener("click", () => {
  download("README.md", readmeText(), "text/markdown");
});

els.downloadJson.addEventListener("click", () => {
  download(`${state.name}.crewdefine.json`, JSON.stringify(state, null, 2), "application/json");
});

els.draftFromPurpose.addEventListener("click", () => {
  assembleTeamFromGoal(state.description);
});

els.loadSample.addEventListener("click", () => {
  state = structuredClone(sampleCrew);
  selectedId = state.agents[0].id;
  shouldClearGoalOnFocus = true;
  commit();
  toast("Sample crew loaded.");
});

els.resetDraft.addEventListener("click", () => {
  state = blankCrew();
  selectedId = state.agents[0].id;
  shouldClearGoalOnFocus = true;
  commit();
  toast("Draft reset.");
});

render();
